// Service worker: gọi Giphy API, tải ảnh dự phòng, lấy link GIF từ trang Tenor,
// và quản lý mã kích hoạt bản trọn đời.

const IMAGE_HOSTS = /^(media\d*\.giphy\.com|i\.giphy\.com|media\.tenor\.com|c\.tenor\.com|i\.imgur\.com)$/;

// Máy chủ thanh toán & kích hoạt (Cloudflare Worker). Đổi sau khi deploy.
const SERVER = 'https://ytgif-thanh-toan.ytgif-thanh-toan.workers.dev';
const RECHECK_MS = 24 * 3600 * 1000;      // kiểm tra lại với máy chủ mỗi ngày
const OFFLINE_GRACE_MS = 14 * 86400 * 1000; // mất mạng vẫn dùng được 14 ngày

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handlers = {
    giphy, fetchImage, resolveTenor,
    openOptions: async () => chrome.runtime.openOptionsPage(),
    openBuy: async () => chrome.tabs.create({ url: SERVER + '/' }),
    licenseStatus, licenseActivate, licenseDeactivate
  };
  const fn = handlers[msg && msg.type];
  if (!fn) return false;
  fn(msg)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true; // trả lời bất đồng bộ
});

async function giphy({ q, offset = 0 }) {
  const { giphyKey = '', rating = 'pg-13' } = await chrome.storage.sync.get(['giphyKey', 'rating']);
  if (!giphyKey) return giphyNoKey(q, offset);
  const endpoint = q ? 'search' : 'trending';
  const params = new URLSearchParams({ api_key: giphyKey, limit: '24', offset: String(offset), rating });
  if (q) { params.set('q', q); params.set('lang', 'vi'); }
  const res = await fetch(`https://api.giphy.com/v1/gifs/${endpoint}?${params}`);
  if (res.status === 401 || res.status === 403) throw new Error('BAD_KEY');
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const json = await res.json();
  return {
    items: json.data.map((g) => ({
      code: `[gif:g:${g.id}]`,
      preview: (g.images.fixed_width_small || g.images.fixed_width || g.images.original).url,
      title: g.title || ''
    })),
    next: json.pagination ? json.pagination.offset + json.pagination.count : 0,
    total: json.pagination ? json.pagination.total_count : 0
  };
}

// Không có API key: đọc trang tìm kiếm công khai giphy.com/search/<từ khoá>
// và lấy danh sách GIF trong dữ liệu của trang (chỉ có trang đầu, ~25-35 GIF).
const pageCache = new Map();
async function giphyNoKey(q, offset) {
  if (offset > 0) return { items: [], next: 0, total: 0 };
  const term = (q || 'funny').trim().toLowerCase().replace(/\s+/g, '-');
  let items = pageCache.get(term);
  if (!items) {
    const res = await fetch('https://giphy.com/search/' + encodeURIComponent(term), { credentials: 'omit' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = (await res.text()).replace(/\\"/g, '"');
    const seen = new Set();
    items = [];
    for (const m of html.matchAll(/"type":"gif","id":"([A-Za-z0-9]+)"(?:[^{}]{0,400}?"title":"([^"]{0,120})")?/g)) {
      if (seen.has(m[1])) continue;
      seen.add(m[1]);
      items.push({
        code: `[gif:g:${m[1]}]`,
        preview: `https://media.giphy.com/media/${m[1]}/200w_d.gif`,
        title: m[2] || ''
      });
    }
    pageCache.set(term, items);
    if (pageCache.size > 50) pageCache.delete(pageCache.keys().next().value);
  }
  return { items, next: 0, total: 0 };
}

// Dùng khi trang chặn tải ảnh trực tiếp: tải ở đây rồi trả về data URL.
async function fetchImage({ url }) {
  const u = new URL(url);
  if (u.protocol !== 'https:' || !IMAGE_HOSTS.test(u.hostname)) throw new Error('HOST_NOT_ALLOWED');
  const res = await fetch(u.href);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const type = res.headers.get('content-type') || 'image/gif';
  if (!type.startsWith('image/')) throw new Error('NOT_IMAGE');
  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf.length > 15 * 1024 * 1024) throw new Error('TOO_LARGE');
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${type};base64,${btoa(bin)}`;
}

// ---------- Mã kích hoạt ----------
async function deviceId() {
  let { deviceId } = await chrome.storage.local.get('deviceId');
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ deviceId });
  }
  return deviceId;
}

async function callServer(path, data) {
  const res = await fetch(SERVER + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  let json = {};
  try { json = await res.json(); } catch (e) {}
  return { status: res.status, json };
}

// pro = đã kích hoạt và còn hiệu lực. Mất mạng thì vẫn tin kết quả gần nhất trong 14 ngày.
async function licenseStatus() {
  const { lic } = await chrome.storage.local.get('lic');
  if (!lic || !lic.key) return { pro: false };
  if (Date.now() - (lic.checkedAt || 0) > RECHECK_MS) {
    try {
      const r = await callServer('/api/verify', { key: lic.key, device: await deviceId() });
      if (r.json.ok) { lic.ok = true; lic.checkedAt = Date.now(); lic.error = ''; }
      else if (r.status === 403 || r.status === 404) { lic.ok = false; lic.error = r.json.error || 'Mã không còn hiệu lực.'; }
      await chrome.storage.local.set({ lic });
    } catch (e) { /* mất mạng: giữ nguyên */ }
  }
  const pro = !!lic.ok && Date.now() - (lic.checkedAt || 0) < OFFLINE_GRACE_MS;
  return { pro, key: lic.key, error: lic.error || '' };
}

async function licenseActivate({ key }) {
  key = String(key || '').trim().toUpperCase();
  if (!/^YTGIF-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(key)) throw new Error('Mã kích hoạt có dạng YTGIF-XXXX-XXXX-XXXX.');
  let r;
  try { r = await callServer('/api/activate', { key, device: await deviceId() }); }
  catch (e) { throw new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.'); }
  if (!r.json.ok) throw new Error(r.json.error || 'Kích hoạt không thành công.');
  await chrome.storage.local.set({ lic: { key, ok: true, sig: r.json.sig, checkedAt: Date.now(), error: '' } });
  return { pro: true, key, devices: r.json.devices, max: r.json.max };
}

async function licenseDeactivate() {
  const { lic } = await chrome.storage.local.get('lic');
  if (lic && lic.key) {
    try { await callServer('/api/deactivate', { key: lic.key, device: await deviceId() }); } catch (e) {}
  }
  await chrome.storage.local.remove('lic');
  return { pro: false };
}

// Link trang tenor.com/view/... -> link file media.tenor.com/....gif
async function resolveTenor({ url }) {
  const u = new URL(url);
  if (!/(^|\.)tenor\.com$/.test(u.hostname)) throw new Error('NOT_TENOR');
  const res = await fetch(u.href);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const html = await res.text();
  const m = html.match(/https:\/\/media\.tenor\.com\/[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+\.gif/);
  if (!m) throw new Error('NOT_FOUND');
  return m[0];
}
