// Service worker: gọi Giphy API, tải ảnh dự phòng, lấy link GIF từ trang Tenor.
// license.js: mã kích hoạt bản trọn đời (module dùng chung, bản gốc ở G:\game\h3g-license).

const IMAGE_HOSTS = /^(media\d*\.giphy\.com|i\.giphy\.com|media\.tenor\.com|c\.tenor\.com|i\.imgur\.com)$/;

importScripts('license.js');
H3GLicense.init({ product: 'ytgif', keyPrefix: 'YTGIF' });

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handlers = {
    giphy, fetchImage, resolveTenor,
    openOptions: async () => chrome.runtime.openOptionsPage(),
  };
  if (H3GLicense.handles(msg)) return H3GLicense.respond(msg, sendResponse);
  const fn = handlers[msg && msg.type];
  if (!fn) return false;
  fn(msg)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true; // trả lời bất đồng bộ
});

async function giphy({ q, offset = 0 }) {
  const { giphyKey = '', rating = 'pg-13' } = await chrome.storage.sync.get(['giphyKey', 'rating']);
  if (!giphyKey) return giphyNoKey(q, offset);
  const endpoint = q ? 'search' : 'trending';
  const params = new URLSearchParams({ api_key: giphyKey, limit: '24', offset: String(offset), rating });
  if (q) { params.set('q', q); params.set('lang', 'vi'); }
  const res = await fetch(`https://api.giphy.com/v1/gifs/${endpoint}?${params}`);
  if (res.status === 401 || res.status === 403) throw new Error('BAD_KEY');
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const json = await res.json();
  return {
    items: json.data.map((g) => ({
      code: `[gif:g:${g.id}]`,
      preview: (g.images.fixed_width_small || g.images.fixed_width || g.images.original).url,
      title: g.title || ''
    })),
    next: json.pagination ? json.pagination.offset + json.pagination.count : 0,
    total: json.pagination ? json.pagination.total_count : 0
  };
}

// Không có API key: đọc trang tìm kiếm công khai giphy.com/search/<từ khoá>
// và lấy danh sách GIF trong dữ liệu của trang (chỉ có trang đầu, ~25-35 GIF).
const pageCache = new Map();
async function giphyNoKey(q, offset) {
  if (offset > 0) return { items: [], next: 0, total: 0 };
  const term = (q || 'funny').trim().toLowerCase().replace(/\s+/g, '-');
  let items = pageCache.get(term);
  if (!items) {
    const res = await fetch('https://giphy.com/search/' + encodeURIComponent(term), { credentials: 'omit' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = (await res.text()).replace(/\\"/g, '"');
    const seen = new Set();
    items = [];
    for (const m of html.matchAll(/"type":"gif","id":"([A-Za-z0-9]+)"(?:[^{}]{0,400}?"title":"([^"]{0,120})")?/g)) {
      if (seen.has(m[1])) continue;
      seen.add(m[1]);
      items.push({
        code: `[gif:g:${m[1]}]`,
        preview: `https://media.giphy.com/media/${m[1]}/200w_d.gif`,
        title: m[2] || ''
      });
    }
    pageCache.set(term, items);
    if (pageCache.size > 50) pageCache.delete(pageCache.keys().next().value);
  }
  return { items, next: 0, total: 0 };
}

// Dùng khi trang chặn tải ảnh trực tiếp: tải ở đây rồi trả về data URL.
async function fetchImage({ url }) {
  const u = new URL(url);
  if (u.protocol !== 'https:' || !IMAGE_HOSTS.test(u.hostname)) throw new Error('HOST_NOT_ALLOWED');
  const res = await fetch(u.href);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const type = res.headers.get('content-type') || 'image/gif';
  if (!type.startsWith('image/')) throw new Error('NOT_IMAGE');
  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf.length > 15 * 1024 * 1024) throw new Error('TOO_LARGE');
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${type};base64,${btoa(bin)}`;
}

// Link trang tenor.com/view/... -> link file media.tenor.com/....gif
async function resolveTenor({ url }) {
  const u = new URL(url);
  if (!/(^|\.)tenor\.com$/.test(u.hostname)) throw new Error('NOT_TENOR');
  const res = await fetch(u.href);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const html = await res.text();
  const m = html.match(/https:\/\/media\.tenor\.com\/[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+\.gif/);
  if (!m) throw new Error('NOT_FOUND');
  return m[0];
}
