const DEFAULTS = { enabled: true, giphyKey: '', rating: 'pg-13', maxHeight: 180 };
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS, (s) => {
  $('enabled').checked = s.enabled;
  $('giphyKey').value = s.giphyKey;
  $('rating').value = s.rating;
  $('maxHeight').value = s.maxHeight;
});

// ---------- Mã kích hoạt ----------
function ask(msg) {
  return new Promise((resolve, reject) => chrome.runtime.sendMessage(msg, (res) => {
    if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
    if (!res || !res.ok) return reject(new Error(res ? res.error : 'Không có phản hồi'));
    resolve(res.data);
  }));
}
function showLicense(s, note) {
  $('licState').textContent = s.pro ? '✅ Đã kích hoạt bản trọn đời' : '🔒 Bản miễn phí (chỉ xem GIF trong bình luận)';
  $('licState').classList.toggle('pro', !!s.pro);
  $('licForm').hidden = !!s.pro;
  $('deactivate').hidden = !s.key;
  const msg = note || (s.pro ? 'Mã: ' + s.key : s.error || '');
  $('proMsg').textContent = msg;
  $('proMsg').classList.toggle('err', !s.pro && !!s.error && !note);
}
ask({ type: 'licenseStatus' }).then((s) => showLicense(s)).catch(() => showLicense({ pro: false }));

$('activate').addEventListener('click', async () => {
  const key = $('licInput').value;
  $('activate').disabled = true;
  $('proMsg').classList.remove('err');
  $('proMsg').textContent = 'Đang kích hoạt…';
  try {
    const s = await ask({ type: 'licenseActivate', key });
    showLicense(s, 'Kích hoạt thành công! Máy này là máy ' + s.devices + '/' + s.max + '. Mở lại YouTube để dùng.');
    $('licInput').value = '';
  } catch (e) {
    $('proMsg').textContent = e.message;
    $('proMsg').classList.add('err');
  } finally {
    $('activate').disabled = false;
  }
});
$('licInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('activate').click(); });
$('buy').addEventListener('click', () => ask({ type: 'openBuy' }).catch(() => {}));
$('deactivate').addEventListener('click', async () => {
  if (!confirm('Gỡ mã khỏi máy này? Bạn có thể kích hoạt lại sau bằng cùng mã.')) return;
  showLicense(await ask({ type: 'licenseDeactivate' }), 'Đã gỡ mã khỏi máy này.');
});

$('save').addEventListener('click', () => {
  const maxHeight = Math.min(600, Math.max(60, parseInt($('maxHeight').value, 10) || DEFAULTS.maxHeight));
  $('maxHeight').value = maxHeight;
  chrome.storage.sync.set({
    enabled: $('enabled').checked,
    giphyKey: $('giphyKey').value.trim(),
    rating: $('rating').value,
    maxHeight
  }, () => {
    $('status').textContent = 'Đã lưu ✓';
    setTimeout(() => ($('status').textContent = ''), 1500);
  });
});

