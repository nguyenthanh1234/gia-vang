// GIF tự tạo: emoji + chữ + hiệu ứng, vẽ bằng canvas.
// Toàn bộ thông tin được mã hoá gọn trong bình luận ([gif:x:...]) nên không cần nơi lưu ảnh.
// Có thể xuất ra file .gif thật để dùng ở nơi khác.
(() => {
  'use strict';

  const TAU = Math.PI * 2;

  const EFFECTS = {
    bounce:   { name: 'Nảy',       dur: 1000 },
    shake:    { name: 'Lắc',       dur: 800 },
    pulse:    { name: 'Đập',       dur: 1000 },
    spin:     { name: 'Xoay',      dur: 1500 },
    zoom:     { name: 'Bật ra',    dur: 2000 },
    float:    { name: 'Lơ lửng',   dur: 2000 },
    blink:    { name: 'Nhấp nháy', dur: 1200 },
    glow:     { name: 'Phát sáng', dur: 1500 },
    rainbow:  { name: 'Cầu vồng',  dur: 2000 },
    wave:     { name: 'Sóng chữ',  dur: 1500 },
    type:     { name: 'Gõ chữ',    dur: 3000 },
    rain:     { name: 'Mưa emoji', dur: 2000 },
    hearts:   { name: 'Tim bay',   dur: 2500 },
    confetti: { name: 'Pháo giấy', dur: 2500 }
  };
  const COLORS = ['#ffffff', '#111111', '#ffd400', '#ff3b30', '#ff5fa2', '#ff9500', '#34c759', '#32d2ff', '#3d7bff', '#a259ff'];
  // null = trong suốt, 1 màu = nền đơn, 2 màu = chuyển màu, 'disco' = đổi màu liên tục
  const BGS = [null, ['#ffffff'], ['#111111'], ['#ffe066'], ['#ff5f6d', '#ffc371'], ['#4e54c8', '#8f94fb'],
    ['#11998e', '#38ef7d'], ['#f12711', '#f5af19'], ['#0f2027', '#2c5364'], 'disco'];
  const FONTS = [
    { name: 'Đậm',      css: (s) => `900 ${s}px 'Arial Black', Arial, sans-serif` },
    { name: 'Vui nhộn', css: (s) => `bold ${s}px 'Comic Sans MS', 'Comic Neue', cursive` },
    { name: 'Hiện đại', css: (s) => `bold ${s}px 'Segoe UI', Roboto, Arial, sans-serif` },
    { name: 'Cổ điển',  css: (s) => `italic bold ${s}px Georgia, 'Times New Roman', serif` }
  ];
  const SHAPES = [{ name: 'Vuông', W: 200, H: 200 }, { name: 'Ngang', W: 320, H: 160 }];
  const EMOJI_FONT = "'Segoe UI Emoji','Apple Color Emoji','Noto Color Emoji',sans-serif";
  const MAX_M = 24, MAX_X = 60;

  const PRESETS = [
    { e: 'shake', m: '😂' },
    { e: 'pulse', m: '❤️' },
    { e: 'bounce', m: '👍', x: 'Hay quá!' },
    { e: 'shake', m: '👏', x: 'Đỉnh!', f: 2 },
    { e: 'glow', m: '🔥', x: 'Cháy quá', f: 5 },
    { e: 'rain', m: '😭' },
    { e: 'hearts', m: '🥰' },
    { e: 'confetti', m: '🎉', x: 'Chúc mừng!', f: 2 },
    { e: 'zoom', m: '😮', x: 'WOW', f: 2 },
    { e: 'shake', m: '🤔', x: 'Hmm...' },
    { e: 'shake', m: '😡', x: 'Tức!', f: 3 },
    { e: 'pulse', m: '💯' },
    { e: 'bounce', m: '🙏', x: 'Cảm ơn', o: 1 },
    { e: 'zoom', m: '😎', x: 'Chất', f: 2 },
    { e: 'blink', m: '👀', x: 'Hóng', f: 7 },
    { e: 'spin', m: '🤣' },
    { e: 'rainbow', x: 'FIRST!', k: 1 },
    { e: 'wave', x: 'Hahaha', f: 2, k: 1, o: 1 },
    { e: 'type', x: 'Ai 2026 điểm danh', k: 1, b: 8 },
    { e: 'glow', x: 'GG', f: 7, b: 2 },
    { e: 'rainbow', x: 'Quá đỉnh', b: 2, k: 1 },
    { e: 'wave', x: 'Like nhẹ', b: 5, k: 1 },
    { e: 'type', x: 'Xem lần thứ 10 rồi', b: 4, k: 1 },
    { e: 'bounce', m: '🐧', x: 'Chào', o: 1, f: 8 }
  ].map((p) => Object.assign({ e: 'bounce', f: 0, b: 0, o: 0, k: 0, m: '', x: '' }, p));

  // ---------- Mã hoá ----------

  function clean(str, max) {
    return Array.from(String(str || '').replace(/[\u0000-\u001f\u007f]/g, '')).slice(0, max).join('').trim();
  }

  function encode(s) {
    const str = ['1', s.e, s.f, s.b, s.o, s.k, clean(s.m, MAX_M), clean(s.x, MAX_X)].join('\n');
    let bin = '';
    new TextEncoder().encode(str).forEach((b) => { bin += String.fromCharCode(b); });
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function decode(val) {
    try {
      if (!/^[A-Za-z0-9_-]+$/.test(val)) return null;
      const bin = atob(val.replace(/-/g, '+').replace(/_/g, '/'));
      const str = new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
      const p = str.split('\n');
      if (p.length !== 8 || p[0] !== '1' || !EFFECTS.hasOwnProperty(p[1])) return null;
      if (!p.slice(2, 6).every((v) => /^\d$/.test(v))) return null;
      const s = { e: p[1], f: +p[2], b: +p[3], o: +p[4], k: +p[5], m: clean(p[6], MAX_M), x: clean(p[7], MAX_X) };
      if (s.f >= COLORS.length || s.b >= BGS.length || s.o >= FONTS.length || s.k >= SHAPES.length) return null;
      if (!s.m && !s.x) return null;
      return s;
    } catch {
      return null;
    }
  }

  // ---------- Bố cục ----------

  function graphemes(str) {
    if (window.Intl && Intl.Segmenter) return Array.from(new Intl.Segmenter().segment(str), (g) => g.segment);
    return Array.from(str);
  }

  function wrap(ctx, text, maxW) {
    const words = text.split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = '';
    for (const w of words) {
      const test = cur ? cur + ' ' + w : w;
      if (cur && ctx.measureText(test).width > maxW) { lines.push(cur); cur = w; } else cur = test;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  const layoutCache = new Map();
  function layout(ctx, W, H, s) {
    const key = [W, H, s.o, s.m, s.x].join('|');
    let L = layoutCache.get(key);
    if (L) return L;

    const pad = Math.round(Math.min(W, H) * 0.08);
    const maxW = W - pad * 2;
    L = { emojiSize: 0, emojiY: H / 2, lines: null, fontSize: 0 };

    if (s.m) {
      let size = s.x ? H * 0.4 : H * 0.66;
      ctx.font = `${size}px ${EMOJI_FONT}`;
      const w = ctx.measureText(s.m).width;
      if (w > maxW) size *= maxW / w;
      L.emojiSize = size;
      L.emojiY = s.x ? pad + size / 2 : H / 2;
    }

    if (s.x) {
      const top = s.m ? pad + L.emojiSize + pad * 0.3 : pad;
      const boxH = H - top - pad;
      let fs = Math.floor(Math.min(boxH, H * 0.4));
      let lines = [];
      for (; fs > 8; fs -= 2) {
        ctx.font = FONTS[s.o].css(fs);
        lines = wrap(ctx, s.x, maxW);
        if (lines.length * fs * 1.12 <= boxH && lines.every((l) => ctx.measureText(l).width <= maxW)) break;
      }
      const lineH = fs * 1.12;
      const textTop = top + (boxH - lines.length * lineH) / 2;
      ctx.font = FONTS[s.o].css(fs);
      L.fontSize = fs;
      L.lines = lines.map((line, li) => {
        const chars = Array.from(line);
        const x0 = W / 2 - ctx.measureText(line).width / 2;
        const xs = [];
        let acc = '';
        for (const ch of chars) {
          const before = ctx.measureText(acc).width;
          acc += ch;
          xs.push(x0 + (before + ctx.measureText(acc).width) / 2);
        }
        return { text: line, chars, xs, y: textTop + lineH * (li + 0.5) };
      });
    }

    layoutCache.set(key, L);
    if (layoutCache.size > 300) layoutCache.delete(layoutCache.keys().next().value);
    return L;
  }

  // ---------- Vẽ ----------

  function rand(i, k) {
    const v = Math.sin(i * 127.1 + k * 311.7) * 43758.5453;
    return v - Math.floor(v);
  }

  function luminance(hex) {
    const n = parseInt(hex.slice(1), 16);
    return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  }

  function easeOutBack(x) {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
  }

  function drawBg(ctx, W, H, b, t) {
    const bg = BGS[b];
    if (!bg) return;
    let fill;
    if (bg === 'disco') {
      const h = 360 * t;
      fill = ctx.createLinearGradient(0, 0, W, H);
      fill.addColorStop(0, `hsl(${h},90%,55%)`);
      fill.addColorStop(1, `hsl(${h + 120},90%,55%)`);
    } else if (bg.length === 1) {
      fill = bg[0];
    } else {
      fill = ctx.createLinearGradient(0, 0, W, H);
      fill.addColorStop(0, bg[0]);
      fill.addColorStop(1, bg[1]);
    }
    ctx.fillStyle = fill;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(0, 0, W, H, Math.min(W, H) * 0.08);
    else ctx.rect(0, 0, W, H);
    ctx.fill();
  }

  function particles(ctx, W, H, t, glyph, up) {
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = 0.85;
    for (let i = 0; i < 12; i++) {
      const size = H * (0.08 + 0.07 * rand(i, 1));
      const speed = 1 + Math.floor(rand(i, 3) * 2);
      const p = (rand(i, 4) + t * speed) % 1;
      const x = size + rand(i, 2) * (W - size * 2) + Math.sin(TAU * (t * speed + rand(i, 5))) * size * 0.3;
      const y = up ? H + size - p * (H + size * 2) : -size + p * (H + size * 2);
      ctx.font = `${size}px ${EMOJI_FONT}`;
      ctx.fillText(glyph, x, y);
    }
    ctx.restore();
  }

  function confetti(ctx, W, H, t) {
    ctx.save();
    for (let i = 0; i < 26; i++) {
      const w = 5 + rand(i, 1) * 5, h = 8 + rand(i, 6) * 6;
      const speed = 1 + Math.floor(rand(i, 3) * 2);
      const p = (rand(i, 4) + t * speed) % 1;
      const x = rand(i, 2) * W + Math.sin(TAU * (t + rand(i, 5))) * 8;
      const y = -h + p * (H + h * 2);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(TAU * (t * speed + rand(i, 7)));
      ctx.fillStyle = COLORS[2 + (i % 8)];
      ctx.fillRect(-w / 2, -h / 2, w, h * Math.cos(TAU * (t * speed * 2 + rand(i, 8))));
      ctx.restore();
    }
    ctx.restore();
  }

  // t: vị trí trong vòng lặp, từ 0 đến 1
  function draw(ctx, W, H, s, t) {
    ctx.save();
    ctx.clearRect(0, 0, W, H);
    drawBg(ctx, W, H, s.b, t);
    const L = layout(ctx, W, H, s);
    const e = s.e;

    if (e === 'rain') particles(ctx, W, H, t, s.m ? graphemes(s.m)[0] : '💧', false);
    if (e === 'hearts') particles(ctx, W, H, t, '❤️', true);
    if (e === 'confetti') confetti(ctx, W, H, t);

    // Chuyển động của cả nhóm (emoji + chữ)
    let gx = 0, gy = 0, gs = 1, gr = 0, ga = 1, er = 0, ey = 0;
    switch (e) {
      case 'bounce': gy = -Math.abs(Math.sin(TAU * t)) * H * 0.12; break;
      case 'shake': gr = Math.sin(TAU * t * 4) * 0.12; gx = Math.sin(TAU * t * 8) * W * 0.015; break;
      case 'pulse': gs = 1 + 0.14 * Math.pow(Math.max(0, Math.sin(TAU * t * 2)), 2); break;
      case 'spin': er = TAU * t; break;
      case 'zoom': gs = Math.max(0.001, t < 0.35 ? easeOutBack(t / 0.35) : t > 0.9 ? 1 - (t - 0.9) / 0.1 : 1); break;
      case 'blink': ga = 0.15 + 0.85 * (0.5 + 0.5 * Math.cos(TAU * t * 2)); break;
      case 'float': case 'rain': case 'hearts': case 'confetti': gy = Math.sin(TAU * t) * H * 0.03; break;
      default: ey = Math.sin(TAU * t) * H * 0.02; // hiệu ứng chữ: emoji nhấp nhô nhẹ
    }
    ctx.globalAlpha = ga;
    ctx.translate(W / 2 + gx, H / 2 + gy);
    ctx.rotate(gr);
    ctx.scale(gs, gs);
    ctx.translate(-W / 2, -H / 2);

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const fill = COLORS[s.f];

    if (s.m) {
      ctx.save();
      ctx.translate(W / 2, L.emojiY + ey);
      if (er) ctx.rotate(er);
      if (e === 'glow') { ctx.shadowColor = fill; ctx.shadowBlur = L.emojiSize * (0.25 + 0.2 * Math.sin(TAU * t * 3)); }
      ctx.font = `${L.emojiSize}px ${EMOJI_FONT}`;
      ctx.fillText(s.m, 0, L.emojiSize * 0.06);
      ctx.restore();
    }

    if (L.lines) {
      ctx.font = FONTS[s.o].css(L.fontSize);
      ctx.lineJoin = 'round';
      ctx.miterLimit = 2;
      ctx.lineWidth = Math.max(2, L.fontSize * 0.16);
      ctx.strokeStyle = luminance(fill) > 0.5 ? '#000' : '#fff';
      if (e === 'glow') { ctx.shadowColor = fill; ctx.shadowBlur = L.fontSize * (0.3 + 0.25 * Math.sin(TAU * t * 3)); }

      const perChar = e === 'wave' || e === 'rainbow' || e === 'type';
      const total = L.lines.reduce((n, l) => n + l.chars.length, 0);
      const shown = e === 'type' ? Math.floor(Math.min(1, t / 0.75) * total) : total;

      // 2 lượt: viền trước, màu chữ sau, để viền chữ sau không đè lên chữ trước
      for (const pass of ['stroke', 'fill']) {
        let idx = 0;
        for (const line of L.lines) {
          if (!perChar) {
            ctx.fillStyle = fill;
            pass === 'stroke' ? ctx.strokeText(line.text, W / 2, line.y) : ctx.fillText(line.text, W / 2, line.y);
            continue;
          }
          for (let i = 0; i < line.chars.length; i++, idx++) {
            if (idx >= shown) break;
            const dy = e === 'wave' ? Math.sin(TAU * t * 2 - idx * 0.6) * L.fontSize * 0.22 : 0;
            ctx.fillStyle = e === 'rainbow' ? `hsl(${((360 * (t - idx * 0.07)) % 360 + 360) % 360},95%,60%)` : fill;
            pass === 'stroke'
              ? ctx.strokeText(line.chars[i], line.xs[i], line.y + dy)
              : ctx.fillText(line.chars[i], line.xs[i], line.y + dy);
          }
        }
      }
    }
    ctx.restore();
  }

  // ---------- Canvas động (chỉ chạy khi đang hiện trên màn hình) ----------

  const live = new Set();
  let running = false;
  let lastTick = 0;
  const io = new IntersectionObserver((entries) => {
    for (const en of entries) en.isIntersecting ? live.add(en.target) : live.delete(en.target);
    if (live.size && !running) { running = true; requestAnimationFrame(tick); }
  });

  function tick(now) {
    if (!live.size) { running = false; return; }
    requestAnimationFrame(tick);
    if (now - lastTick < 33) return; // ~30 khung hình/giây
    lastTick = now;
    for (const c of live) {
      if (!c.isConnected) { live.delete(c); io.unobserve(c); continue; }
      const st = c._ytgs;
      draw(st.ctx, st.W, st.H, st.spec, (now % st.dur) / st.dur);
    }
  }

  function setSpec(c, spec) {
    const sh = SHAPES[spec.k];
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (!c._ytgs || c._ytgs.W !== sh.W || c._ytgs.H !== sh.H) {
      c.width = Math.round(sh.W * dpr);
      c.height = Math.round(sh.H * dpr);
      const ctx = c.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      c._ytgs = { ctx, W: sh.W, H: sh.H };
    }
    Object.assign(c._ytgs, { spec, dur: EFFECTS[spec.e].dur });
    draw(c._ytgs.ctx, sh.W, sh.H, spec, 0.8);
  }

  function makeCanvas(spec, cls) {
    const c = document.createElement('canvas');
    if (cls) c.className = cls;
    setSpec(c, spec);
    io.observe(c);
    return c;
  }

  // ---------- Xuất file .gif ----------

  function lzw(indices, minCodeSize) {
    const clear = 1 << minCodeSize, eoi = clear + 1;
    let codeSize = minCodeSize + 1, next = eoi + 1;
    let dict = new Map();
    const out = [];
    let cur = 0, nbits = 0;
    const emit = (c) => {
      cur |= c << nbits;
      nbits += codeSize;
      while (nbits >= 8) { out.push(cur & 255); cur >>>= 8; nbits -= 8; }
    };
    emit(clear);
    let prefix = indices[0];
    for (let i = 1; i < indices.length; i++) {
      const k = indices[i];
      const key = prefix * 256 + k;
      const v = dict.get(key);
      if (v !== undefined) { prefix = v; continue; }
      emit(prefix);
      if (next === 4096) {
        emit(clear);
        dict = new Map();
        codeSize = minCodeSize + 1;
        next = eoi + 1;
      } else {
        if (next >= (1 << codeSize)) codeSize++;
        dict.set(key, next++);
      }
      prefix = k;
    }
    emit(prefix);
    emit(eoi);
    if (nbits > 0) out.push(cur & 255);
    return out;
  }

  function encodeGif(W, H, frames, delay) {
    // Bảng màu: 255 màu phổ biến nhất (mỗi kênh 5 bit), ô 0 dành cho trong suốt
    const hist = new Uint32Array(32768);
    const sr = new Float64Array(32768), sg = new Float64Array(32768), sb = new Float64Array(32768);
    let hasT = false;
    for (const d of frames) {
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) { hasT = true; continue; }
        const k = ((d[i] >> 3) << 10) | ((d[i + 1] >> 3) << 5) | (d[i + 2] >> 3);
        hist[k]++; sr[k] += d[i]; sg[k] += d[i + 1]; sb[k] += d[i + 2];
      }
    }
    const keys = [];
    for (let k = 0; k < 32768; k++) if (hist[k]) keys.push(k);
    keys.sort((a, b) => hist[b] - hist[a]);
    const pal = new Uint8Array(768);
    const top = keys.slice(0, 255);
    top.forEach((k, j) => {
      pal[(j + 1) * 3] = sr[k] / hist[k];
      pal[(j + 1) * 3 + 1] = sg[k] / hist[k];
      pal[(j + 1) * 3 + 2] = sb[k] / hist[k];
    });
    const npal = top.length + 1;
    const map = new Int16Array(32768).fill(-1);
    const nearest = (k) => {
      const r = sr[k] / hist[k], g = sg[k] / hist[k], b = sb[k] / hist[k];
      let best = 1, bd = Infinity;
      for (let j = 1; j < npal; j++) {
        const dr = pal[j * 3] - r, dg = pal[j * 3 + 1] - g, db = pal[j * 3 + 2] - b;
        const dist = dr * dr * 2 + dg * dg * 4 + db * db * 3;
        if (dist < bd) { bd = dist; best = j; }
      }
      return best;
    };

    const out = [];
    const w16 = (v) => out.push(v & 255, (v >> 8) & 255);
    const str = (s) => { for (const ch of s) out.push(ch.charCodeAt(0)); };
    str('GIF89a');
    w16(W); w16(H);
    out.push(0xF7, 0, 0);
    for (let i = 0; i < 768; i++) out.push(pal[i]);
    out.push(0x21, 0xFF, 0x0B); str('NETSCAPE2.0'); out.push(3, 1, 0, 0, 0); // lặp vô hạn

    const idx = new Uint8Array(W * H);
    for (const d of frames) {
      for (let p = 0, i = 0; p < idx.length; p++, i += 4) {
        if (d[i + 3] < 128) { idx[p] = 0; continue; }
        const k = ((d[i] >> 3) << 10) | ((d[i + 1] >> 3) << 5) | (d[i + 2] >> 3);
        let m = map[k];
        if (m < 0) m = map[k] = nearest(k);
        idx[p] = m;
      }
      out.push(0x21, 0xF9, 4, hasT ? 0x09 : 0x04, delay & 255, (delay >> 8) & 255, 0, 0);
      out.push(0x2C); w16(0); w16(0); w16(W); w16(H); out.push(0);
      out.push(8);
      const data = lzw(idx, 8);
      for (let i = 0; i < data.length; i += 255) {
        const n = Math.min(255, data.length - i);
        out.push(n);
        for (let j = 0; j < n; j++) out.push(data[i + j]);
      }
      out.push(0);
    }
    out.push(0x3B);
    return new Uint8Array(out);
  }

  function toGif(spec) {
    const { W, H } = SHAPES[spec.k];
    const dur = EFFECTS[spec.e].dur;
    const n = Math.max(10, Math.min(40, Math.round(dur / 60)));
    const delay = Math.max(2, Math.round(dur / n / 10)); // đơn vị 1/100 giây
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const frames = [];
    for (let i = 0; i < n; i++) {
      draw(ctx, W, H, spec, i / n);
      frames.push(ctx.getImageData(0, 0, W, H).data);
    }
    return new Blob([encodeGif(W, H, frames, delay)], { type: 'image/gif' });
  }

  self.YTGS = { EFFECTS, COLORS, BGS, FONTS, SHAPES, PRESETS, encode, decode, makeCanvas, setSpec, toGif, _lzw: lzw, _encodeGif: encodeGif };
})();
