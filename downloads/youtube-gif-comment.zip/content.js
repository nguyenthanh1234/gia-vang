(() => {
  'use strict';

  // Mã GIF trong bình luận:
  //   [gif:g:<id>]            -> Giphy
  //   [gif:t:<id>/<tên>.gif]  -> Tenor
  //   [gif:i:<id>.gif]        -> Imgur
  //   [gif:x:<dữ liệu>]       -> GIF tự tạo (vẽ bằng sticker.js)
  const TOKEN_RE = /\[gif:([gtix]):([A-Za-z0-9_\-./]{3,300})\]/g;
  const YTGS = self.YTGS;
  const COMMENT_TEXT_SEL = [
    'ytd-comment-view-model #content-text',
    'ytd-comment-renderer #content-text',
    'ytd-backstage-post-renderer #content-text'
  ].join(',');

  const settings = { enabled: true, maxHeight: 180, giphyKey: '', rating: 'pg-13' };

  chrome.storage.sync.get(settings, (s) => {
    Object.assign(settings, s);
    applyCssVars();
    schedule();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    for (const k in changes) settings[k] = changes[k].newValue;
    applyCssVars();
    document.querySelectorAll(COMMENT_TEXT_SEL).forEach((el) => delete el.dataset.ytgifSig);
    schedule();
  });

  function applyCssVars() {
    document.documentElement.style.setProperty('--ytgif-max-h', (Number(settings.maxHeight) || 180) + 'px');
  }

  function send(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res || !res.ok) return reject(new Error(res ? res.error : 'NO_RESPONSE'));
        resolve(res.data);
      });
    });
  }

  // ---------- Mã <-> link ảnh ----------

  function tokenToUrls(type, val) {
    if (val.includes('..')) return null;
    if (type === 'g' && /^[A-Za-z0-9]+$/.test(val)) {
      return [`https://media.giphy.com/media/${val}/200.webp`, `https://media.giphy.com/media/${val}/200.gif`, `https://media.giphy.com/media/${val}/giphy.gif`];
    }
    if (type === 't' && /^[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+\.(gif|webp)$/.test(val)) {
      return [`https://media.tenor.com/${val}`];
    }
    if (type === 'i' && /^[A-Za-z0-9]+\.(gif|webp|png|jpg)$/.test(val)) {
      return [`https://i.imgur.com/${val}`];
    }
    return null;
  }

  function codeToUrls(code) {
    const m = /^\[gif:([gti]):(.+)\]$/.exec(code);
    return m ? tokenToUrls(m[1], m[2]) : null;
  }

  function stickerCode(spec) {
    return `[gif:x:${YTGS.encode(spec)}]`;
  }

  // Trả về <img> (GIF bên ngoài) hoặc <canvas> (GIF tự tạo), null nếu mã không hợp lệ
  function makeMedia(type, val, cls) {
    if (type === 'x') {
      const spec = YTGS.decode(val);
      return spec ? YTGS.makeCanvas(spec, cls) : null;
    }
    const urls = tokenToUrls(type, val);
    return urls ? makeImg(urls, cls) : null;
  }

  function makeMediaFromCode(code, cls) {
    const m = /^\[gif:([gtix]):(.+)\]$/.exec(code);
    return m ? makeMedia(m[1], m[2], cls) : null;
  }

  async function linkToCode(raw) {
    let u;
    try { u = new URL(raw.trim()); } catch { return null; }
    const h = u.hostname.toLowerCase();
    const p = u.pathname;
    let m;

    if (/(^|\.)giphy\.com$/.test(h)) {
      m = p.match(/\/media\/(?:v1\.[^/]+\/)?([A-Za-z0-9]+)\//) ||
          p.match(/^\/([A-Za-z0-9]+)\.(gif|webp)$/) ||
          p.match(/\/embed\/([A-Za-z0-9]+)/) ||
          p.match(/\/(?:gifs|stickers)\/(?:[^/]*-)?([A-Za-z0-9]+)\/?$/);
      return m ? `[gif:g:${m[1]}]` : null;
    }
    if (h === 'media.tenor.com' || h === 'c.tenor.com') {
      m = p.match(/^\/([A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+\.(gif|webp))$/);
      return m ? `[gif:t:${m[1]}]` : null;
    }
    if (/(^|\.)tenor\.com$/.test(h)) {
      const media = await send({ type: 'resolveTenor', url: u.href });
      return linkToCode(media);
    }
    if (h === 'i.imgur.com') {
      m = p.match(/^\/([A-Za-z0-9]+)\.(gifv|gif|mp4|webp|png|jpe?g)$/i);
      if (!m) return null;
      const ext = { gifv: 'gif', mp4: 'gif', jpeg: 'jpg' }[m[2].toLowerCase()] || m[2].toLowerCase();
      return `[gif:i:${m[1]}.${ext}]`;
    }
    if (h === 'imgur.com' || h === 'www.imgur.com') {
      m = p.match(/^\/([A-Za-z0-9]{5,})$/);
      return m ? `[gif:i:${m[1]}.gif]` : null;
    }
    return null;
  }

  // ---------- Tạo thẻ ảnh ----------
  // Ảnh ngoài được tải qua background rồi gắn vào trang bằng blob:, vì một số trang
  // của YouTube (vd. Shorts) chặn tải ảnh trực tiếp từ tên miền khác
  // ("Unsafe attempt to load URL ... Domains, protocols and ports must match").

  const blobCache = new Map(); // link gốc -> Promise<blob: URL>

  function dataUrlToBlobUrl(dataUrl) {
    const [head, b64] = dataUrl.split(',');
    const type = head.slice(5, head.indexOf(';'));
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return URL.createObjectURL(new Blob([bytes], { type }));
  }

  function loadViaBackground(url) {
    let p = blobCache.get(url);
    if (!p) {
      p = send({ type: 'fetchImage', url }).then(dataUrlToBlobUrl);
      p.catch(() => blobCache.delete(url));
      blobCache.set(url, p);
      if (blobCache.size > 200) {
        const [oldUrl, oldP] = blobCache.entries().next().value;
        blobCache.delete(oldUrl);
        oldP.then((u) => setTimeout(() => URL.revokeObjectURL(u), 60000), () => {});
      }
    }
    return p;
  }

  // Chỉ tải khi ảnh sắp xuất hiện trên màn hình
  const imgObserver = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (!en.isIntersecting) continue;
      imgObserver.unobserve(en.target);
      en.target._ytgifLoad();
    }
  }, { rootMargin: '300px' });

  function makeImg(urls, cls) {
    const img = document.createElement('img');
    img.className = cls ? cls + ' ytgif-loading' : 'ytgif-loading';
    img.decoding = 'async';
    img.alt = 'GIF';
    img._ytgifLoad = async () => {
      for (const u of urls) {
        try {
          img.src = await loadViaBackground(u);
          img.classList.remove('ytgif-loading');
          return;
        } catch { /* thử link sau */ }
      }
      img.replaceWith(Object.assign(document.createElement('span'), {
        className: 'ytgif-broken', textContent: 'GIF không tải được'
      }));
    };
    imgObserver.observe(img);
    return img;
  }

  // ---------- Hiển thị GIF trong bình luận ----------

  function processComment(el) {
    const text = el.textContent;
    if (el.dataset.ytgifSig === text) return;

    const old = el.nextElementSibling;
    if (old && old.classList.contains('ytgif-box')) old.remove();

    if (!settings.enabled) { el.dataset.ytgifSig = text; return; }

    TOKEN_RE.lastIndex = 0;
    if (!TOKEN_RE.test(text)) { el.dataset.ytgifSig = text; return; }

    const box = document.createElement('div');
    box.className = 'ytgif-box';

    // Tìm mã trong từng đoạn chữ, xoá mã khỏi chữ và đưa ảnh xuống khung bên dưới.
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const v = node.nodeValue;
      if (!v.includes('[gif:')) continue;
      let changed = false;
      const stripped = v.replace(TOKEN_RE, (all, type, val) => {
        const media = makeMedia(type, val, 'ytgif-img');
        if (!media) return all;
        changed = true;
        media.title = 'Bấm để phóng to / thu nhỏ';
        const isCanvas = media.tagName === 'CANVAS';
        const size = () => {
          if (!isCanvas) return;
          const h = media._ytgs.H;
          media.style.height = media.classList.contains('ytgif-big')
            ? `min(480px, ${h * 2}px)` : `min(var(--ytgif-max-h, 180px), ${h}px)`;
        };
        size();
        media.addEventListener('click', (e) => {
          e.stopPropagation();
          media.classList.toggle('ytgif-big');
          size();
        });
        box.appendChild(media);
        return '';
      });
      if (changed) node.nodeValue = stripped.replace(/[ \t]{2,}/g, ' ');
    }

    if (box.childElementCount) el.after(box);
    el.dataset.ytgifSig = el.textContent;
  }

  // ---------- Nút GIF trong ô bình luận ----------

  function setupCommentBox(cb) {
    if (cb.querySelector('.ytgif-btn')) return;
    const editable = cb.querySelector('#contenteditable-root');
    if (!editable) return; // ô chưa mở rộng, đợi lần quét sau

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ytgif-btn';
    btn.textContent = 'GIF';
    btn.title = 'Chèn ảnh động';
    btn.addEventListener('mousedown', (e) => e.preventDefault()); // giữ con trỏ trong ô nhập
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      Picker.toggle(cb, btn);
    });

    const emoji = cb.querySelector('#emoji-button');
    const footer = cb.querySelector('#footer');
    if (emoji && emoji.parentElement) emoji.after(btn);
    else if (footer) footer.prepend(btn);
    else cb.appendChild(btn);
  }

  let savedRange = null;
  document.addEventListener('selectionchange', () => {
    const sel = document.getSelection();
    if (!sel.rangeCount) return;
    const r = sel.getRangeAt(0);
    const node = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
    if (node && node.closest('#contenteditable-root')) savedRange = r.cloneRange();
  });

  function insertCode(cb, code) {
    const editable = cb.querySelector('#contenteditable-root');
    if (!editable) return false;
    editable.focus();
    const sel = document.getSelection();
    sel.removeAllRanges();
    if (savedRange && editable.contains(savedRange.startContainer)) {
      sel.addRange(savedRange);
    } else {
      const r = document.createRange();
      r.selectNodeContents(editable);
      r.collapse(false);
      sel.addRange(r);
    }
    const before = editable.textContent;
    const needSpace = before && !/\s$/.test(before) ? ' ' : '';
    // execCommand phát sự kiện input để YouTube bật nút "Bình luận"
    if (!document.execCommand('insertText', false, needSpace + code + ' ')) {
      editable.textContent = before + needSpace + code + ' ';
      editable.dispatchEvent(new InputEvent('input', { bubbles: true }));
    }
    return true;
  }

  // ---------- Bảng chọn GIF ----------

  const Picker = (() => {
    let panel, box, anchor, tab = 'sticker';
    let query = '', nextOffset = 0, loading = false, debounce;
    const QUICK_EMOJI = ['😂', '🤣', '😭', '🥰', '😍', '😎', '🤔', '😮', '😡', '👍', '👏', '🙏', '❤️', '🔥', '💯', '🎉', '👀', '💀', '🐧', '🐱'];
    let mk = { e: 'bounce', f: 0, b: 0, o: 0, k: 0, m: '😂', x: 'Hay quá' };
    let mkCanvas;

    function build() {
      panel = document.createElement('div');
      panel.className = 'ytgif-panel';
      panel.innerHTML = `
        <div class="ytgif-tabs">
          <button data-tab="sticker">Sticker</button>
          <button data-tab="make">Tự tạo</button>
          <button data-tab="search">Tìm GIF</button>
          <button data-tab="recent">Gần đây</button>
          <button data-tab="link">Link</button>
          <button class="ytgif-close" title="Đóng">✕</button>
        </div>
        <div class="ytgif-pane" data-pane="sticker">
          <div class="ytgif-grid"></div>
          <div class="ytgif-attr">Bấm để chèn · ✎ để sửa · Muốn làm cái mới: tab "Tự tạo"</div>
        </div>
        <div class="ytgif-pane" data-pane="make">
          <div class="ytgif-mk-preview"></div>
          <div class="ytgif-mk-controls">
            <div class="ytgif-row">
              <input class="ytgif-mk-m" type="text" maxlength="24" placeholder="Emoji" />
              <input class="ytgif-mk-x" type="text" maxlength="60" placeholder="Chữ (không bắt buộc)" />
            </div>
            <div class="ytgif-emojis"></div>
            <div class="ytgif-label">Hiệu ứng</div>
            <div class="ytgif-chips" data-k="e"></div>
            <div class="ytgif-label">Màu chữ</div>
            <div class="ytgif-swatches" data-k="f"></div>
            <div class="ytgif-label">Nền</div>
            <div class="ytgif-swatches" data-k="b"></div>
            <div class="ytgif-label">Kiểu chữ · Khung</div>
            <div class="ytgif-chips" data-k="o"></div>
            <div class="ytgif-chips" data-k="k"></div>
          </div>
          <div class="ytgif-row">
            <button class="ytgif-insert ytgif-mk-insert">Chèn vào bình luận</button>
            <button class="ytgif-ghost ytgif-mk-dl" title="Tải về file .gif để dùng ở nơi khác">Tải .gif</button>
          </div>
        </div>
        <div class="ytgif-pane" data-pane="search">
          <input class="ytgif-q" type="text" placeholder="Tìm trên GIPHY..." />
          <div class="ytgif-grid"></div>
          <div class="ytgif-msg"></div>
          <div class="ytgif-attr">Powered by GIPHY</div>
        </div>
        <div class="ytgif-pane" data-pane="recent">
          <div class="ytgif-grid"></div>
          <div class="ytgif-msg"></div>
        </div>
        <div class="ytgif-pane" data-pane="link">
          <p class="ytgif-help">Dán link GIF từ <b>Giphy</b>, <b>Tenor</b> hoặc <b>Imgur</b>
            (link trang hoặc link ảnh). Muốn dùng GIF của riêng bạn: tải lên imgur.com rồi dán link.</p>
          <input class="ytgif-link" type="text" placeholder="https://..." />
          <div class="ytgif-preview"></div>
          <button class="ytgif-insert">Chèn vào bình luận</button>
          <div class="ytgif-msg"></div>
        </div>
        <div class="ytgif-lock">
          <button class="ytgif-close ytgif-lock-close" title="Đóng">✕</button>
          <div class="ytgif-lock-ico">🔒</div>
          <div class="ytgif-lock-title">Mở khoá bản trọn đời</div>
          <div class="ytgif-lock-price">29.000đ <span>· trả một lần, dùng mãi mãi</span></div>
          <ul>
            <li>Tìm GIF, dán link Giphy / Tenor / Imgur</li>
            <li>24 sticker động và tự tạo sticker của riêng bạn</li>
            <li>Xuất file .gif cho Facebook, Zalo, Discord</li>
          </ul>
          <button class="ytgif-insert ytgif-buy">Mua ngay bằng chuyển khoản QR</button>
          <button class="ytgif-ghost ytgif-havekey">Tôi đã có mã kích hoạt</button>
          <div class="ytgif-lock-note">Xem GIF trong bình luận của người khác luôn miễn phí.</div>
          <div class="ytgif-msg ytgif-lock-msg"></div>
        </div>`;

      // Chặn phím tắt của YouTube (k, f, m, j, l...) khi đang gõ trong bảng
      for (const t of ['keydown', 'keyup', 'keypress']) {
        panel.addEventListener(t, (e) => {
          e.stopPropagation();
          if (t === 'keydown' && e.key === 'Escape') close();
        });
      }
      panel.addEventListener('mousedown', (e) => e.stopPropagation());

      panel.querySelectorAll('[data-tab]').forEach((b) =>
        b.addEventListener('click', () => show(b.dataset.tab)));
      panel.querySelectorAll('.ytgif-close').forEach((b) => b.addEventListener('click', close));
      panel.querySelector('.ytgif-buy').addEventListener('click', () => send({ type: 'openBuy' }).catch(() => {}));
      panel.querySelector('.ytgif-havekey').addEventListener('click', () => send({ type: 'openOptions' }).catch(() => {}));

      const q = panel.querySelector('.ytgif-q');
      q.addEventListener('input', () => {
        clearTimeout(debounce);
        debounce = setTimeout(() => { query = q.value.trim(); search(true); }, 350);
      });

      const searchGrid = panel.querySelector('[data-pane="search"] .ytgif-grid');
      searchGrid.addEventListener('scroll', () => {
        if (searchGrid.scrollTop + searchGrid.clientHeight > searchGrid.scrollHeight - 80) search(false);
      });

      const linkInput = panel.querySelector('.ytgif-link');
      const linkMsg = panel.querySelector('[data-pane="link"] .ytgif-msg');
      const preview = panel.querySelector('.ytgif-preview');
      let linkCode = null;
      linkInput.addEventListener('input', async () => {
        linkCode = null;
        preview.textContent = '';
        linkMsg.textContent = '';
        const v = linkInput.value.trim();
        if (!v) return;
        linkMsg.textContent = 'Đang kiểm tra...';
        try {
          const code = await linkToCode(v);
          if (linkInput.value.trim() !== v) return;
          if (!code) { linkMsg.textContent = 'Link không hợp lệ (chỉ hỗ trợ Giphy, Tenor, Imgur).'; return; }
          linkCode = code;
          linkMsg.textContent = 'Mã sẽ chèn: ' + code;
          preview.appendChild(makeImg(codeToUrls(code), 'ytgif-preview-img'));
        } catch {
          linkMsg.textContent = 'Không lấy được GIF từ link này.';
        }
      });
      panel.querySelector('.ytgif-insert').addEventListener('click', () => {
        if (!linkCode) { linkMsg.textContent = 'Hãy dán một link GIF hợp lệ trước.'; return; }
        pick({ code: linkCode, preview: codeToUrls(linkCode)[0] });
        linkInput.value = '';
        preview.textContent = '';
        linkMsg.textContent = '';
        linkCode = null;
      });

      buildStickers();
      buildMaker();

      document.body.appendChild(panel);
      document.addEventListener('mousedown', (e) => {
        if (panel.classList.contains('ytgif-open') && !panel.contains(e.target) && e.target !== anchor) close();
      });
      window.addEventListener('resize', position);
      window.addEventListener('scroll', position, true);
    }

    function position() {
      if (!panel || !panel.classList.contains('ytgif-open') || !anchor) return;
      if (!anchor.isConnected) return close();
      const r = anchor.getBoundingClientRect();
      const w = panel.offsetWidth, h = panel.offsetHeight;
      let top = r.bottom + 6;
      if (top + h > innerHeight - 8) top = Math.max(8, r.top - h - 6);
      const left = Math.min(Math.max(8, r.left), innerWidth - w - 8);
      panel.style.top = top + 'px';
      panel.style.left = left + 'px';
    }

    function show(name) {
      tab = name;
      panel.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('ytgif-active', b.dataset.tab === name));
      panel.querySelectorAll('[data-pane]').forEach((p) => p.hidden = p.dataset.pane !== name);
      if (name === 'search') {
        panel.querySelector('.ytgif-q').focus();
        if (!panel.querySelector('[data-pane="search"] .ytgif-grid').childElementCount) search(true);
      } else if (name === 'recent') {
        renderRecent();
      } else if (name === 'link') {
        panel.querySelector('.ytgif-link').focus();
      }
    }

    // ---- Tab Sticker: bộ có sẵn ----
    function buildStickers() {
      const grid = panel.querySelector('[data-pane="sticker"] .ytgif-grid');
      for (const spec of YTGS.PRESETS) {
        grid.appendChild(tile({ code: stickerCode(spec) }, () => editInMaker(spec)));
      }
    }

    function editInMaker(spec) {
      mk = Object.assign({}, spec);
      syncMaker();
      show('make');
    }

    // ---- Tab Tự tạo ----
    function buildMaker() {
      const pane = panel.querySelector('[data-pane="make"]');
      mkCanvas = YTGS.makeCanvas(mk, 'ytgif-mk-canvas');
      pane.querySelector('.ytgif-mk-preview').appendChild(mkCanvas);

      const mIn = pane.querySelector('.ytgif-mk-m');
      const xIn = pane.querySelector('.ytgif-mk-x');
      mIn.addEventListener('input', () => { mk.m = mIn.value; updateMaker(); });
      xIn.addEventListener('input', () => { mk.x = xIn.value; updateMaker(); });

      const emojis = pane.querySelector('.ytgif-emojis');
      for (const em of QUICK_EMOJI) {
        const b = document.createElement('button');
        b.textContent = em;
        b.addEventListener('click', () => { mk.m = em; mIn.value = em; updateMaker(); });
        emojis.appendChild(b);
      }

      const options = {
        e: Object.entries(YTGS.EFFECTS).map(([v, d]) => [v, d.name]),
        o: YTGS.FONTS.map((f, i) => [i, f.name]),
        k: YTGS.SHAPES.map((s, i) => [i, s.name])
      };
      pane.querySelectorAll('.ytgif-chips').forEach((wrap) => {
        const k = wrap.dataset.k;
        for (const [v, label] of options[k]) {
          const b = document.createElement('button');
          b.textContent = label;
          b.dataset.v = v;
          b.addEventListener('click', () => { mk[k] = typeof mk[k] === 'number' ? +v : v; updateMaker(); });
          wrap.appendChild(b);
        }
      });

      pane.querySelectorAll('.ytgif-swatches').forEach((wrap) => {
        const k = wrap.dataset.k;
        const list = k === 'f' ? YTGS.COLORS : YTGS.BGS;
        list.forEach((c, i) => {
          const b = document.createElement('button');
          b.dataset.v = i;
          b.title = k === 'b' && !c ? 'Trong suốt' : k === 'b' && c === 'disco' ? 'Đổi màu' : '';
          b.style.background = k === 'f' ? c
            : !c ? 'repeating-conic-gradient(#bbb 0 25%, #fff 0 50%) 0 0 / 10px 10px'
            : c === 'disco' ? 'conic-gradient(red, yellow, lime, cyan, blue, magenta, red)'
            : c.length === 1 ? c[0] : `linear-gradient(135deg, ${c[0]}, ${c[1]})`;
          b.addEventListener('click', () => { mk[k] = i; updateMaker(); });
          wrap.appendChild(b);
        });
      });

      pane.querySelector('.ytgif-mk-insert').addEventListener('click', () => {
        const spec = currentSpec();
        if (spec) pick({ code: stickerCode(spec) });
      });
      pane.querySelector('.ytgif-mk-dl').addEventListener('click', (e) => {
        const spec = currentSpec();
        if (!spec) return;
        const btn = e.currentTarget;
        btn.disabled = true;
        btn.textContent = 'Đang tạo...';
        setTimeout(() => {
          try {
            const url = URL.createObjectURL(YTGS.toGif(spec));
            const a = document.createElement('a');
            a.href = url;
            a.download = 'sticker-' + Date.now() + '.gif';
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 10000);
          } finally {
            btn.disabled = false;
            btn.textContent = 'Tải .gif';
          }
        }, 30);
      });

      syncMaker();
    }

    function currentSpec() {
      // Chạy qua encode/decode để chắc chắn mã chèn vào giống hệt bản xem trước
      const spec = YTGS.decode(YTGS.encode(mk));
      if (!spec) {
        panel.querySelector('.ytgif-mk-m').focus();
        return null;
      }
      return spec;
    }

    function syncMaker() {
      if (!mkCanvas) return;
      panel.querySelector('.ytgif-mk-m').value = mk.m;
      panel.querySelector('.ytgif-mk-x').value = mk.x;
      updateMaker();
    }

    function updateMaker() {
      panel.querySelectorAll('[data-pane="make"] [data-k]').forEach((wrap) => {
        wrap.querySelectorAll('button').forEach((b) =>
          b.classList.toggle('ytgif-on', String(mk[wrap.dataset.k]) === b.dataset.v));
      });
      const spec = YTGS.decode(YTGS.encode(mk));
      panel.querySelector('.ytgif-mk-insert').disabled = !spec;
      panel.querySelector('.ytgif-mk-dl').disabled = !spec;
      if (spec) YTGS.setSpec(mkCanvas, spec);
    }

    function tile(item, onEdit) {
      const b = document.createElement('button');
      b.className = 'ytgif-tile';
      b.title = item.title || 'Bấm để chèn';
      const media = item.preview
        ? makeImg([item.preview].concat(codeToUrls(item.code) || []), '')
        : makeMediaFromCode(item.code, '');
      if (!media) return b;
      b.appendChild(media);
      b.addEventListener('click', () => pick(item));
      if (onEdit) {
        const ed = document.createElement('span');
        ed.className = 'ytgif-edit';
        ed.textContent = '✎';
        ed.title = 'Sửa sticker này';
        ed.addEventListener('click', (e) => { e.stopPropagation(); onEdit(); });
        b.appendChild(ed);
      }
      return b;
    }

    async function search(reset) {
      if (loading) return;
      const pane = panel.querySelector('[data-pane="search"]');
      const grid = pane.querySelector('.ytgif-grid');
      const msg = pane.querySelector('.ytgif-msg');
      if (reset) { grid.textContent = ''; nextOffset = 0; }
      else if (nextOffset < 0) return;
      loading = true;
      msg.textContent = 'Đang tải...';
      const q = query;
      try {
        const res = await send({ type: 'giphy', q, offset: nextOffset });
        if (q !== query) return;
        res.items.forEach((it) => grid.appendChild(tile(it)));
        nextOffset = res.next < res.total ? res.next : -1;
        msg.textContent = grid.childElementCount ? '' : 'Không tìm thấy GIF nào.';
      } catch (err) {
        const e = err.message;
        msg.innerHTML = e === 'NO_KEY' || e === 'BAD_KEY'
          ? (e === 'NO_KEY' ? 'Chưa có GIPHY API key.' : 'GIPHY API key không đúng.') +
            ' <a href="#" class="ytgif-opt">Mở cài đặt</a> để nhập key (miễn phí). Bạn vẫn có thể dùng tab "Dán link".'
          : 'Lỗi khi tải GIF: ' + e;
        const a = msg.querySelector('.ytgif-opt');
        if (a) a.addEventListener('click', (ev) => { ev.preventDefault(); send({ type: 'openOptions' }).catch(() => {}); });
      } finally {
        loading = false;
      }
    }

    function renderRecent() {
      const pane = panel.querySelector('[data-pane="recent"]');
      const grid = pane.querySelector('.ytgif-grid');
      const msg = pane.querySelector('.ytgif-msg');
      chrome.storage.local.get({ recent: [] }, ({ recent }) => {
        grid.textContent = '';
        recent.forEach((it) => {
          const m = /^\[gif:x:(.+)\]$/.exec(it.code);
          const spec = m && YTGS.decode(m[1]);
          grid.appendChild(tile(it, spec ? () => editInMaker(spec) : null));
        });
        msg.textContent = recent.length ? '' : 'Chưa dùng GIF nào.';
      });
    }

    function pick(item) {
      if (!box || !insertCode(box, item.code)) return;
      chrome.storage.local.get({ recent: [] }, ({ recent }) => {
        recent = [item].concat(recent.filter((r) => r.code !== item.code)).slice(0, 48);
        chrome.storage.local.set({ recent });
      });
      close();
    }

    // Bản miễn phí chỉ xem GIF; đăng GIF cần mã kích hoạt.
    let pro = null;
    function setLocked(locked) {
      panel.classList.toggle('ytgif-locked', locked);
      const msg = panel.querySelector('.ytgif-lock-msg');
      msg.textContent = '';
      if (!locked) show(tab);
      position();
    }
    function refreshLicense() {
      return send({ type: 'licenseStatus' })
        .then((s) => {
          pro = !!s.pro;
          if (panel) {
            setLocked(!pro);
            if (!pro && s.error) panel.querySelector('.ytgif-lock-msg').textContent = s.error;
          }
        })
        .catch(() => { if (panel && pro === null) setLocked(true); });
    }
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.lic) refreshLicense();
    });

    function open(cb, btn) {
      if (!panel) build();
      box = cb;
      anchor = btn;
      panel.classList.add('ytgif-open');
      if (pro) show(tab);
      else setLocked(true);
      position();
      refreshLicense();
    }

    function close() {
      if (panel) panel.classList.remove('ytgif-open');
      anchor = null;
    }

    function toggle(cb, btn) {
      if (panel && panel.classList.contains('ytgif-open') && anchor === btn) close();
      else open(cb, btn);
    }

    return { toggle };
  })();

  // ---------- Quét trang (YouTube là SPA nên theo dõi DOM liên tục) ----------

  let scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      document.querySelectorAll('ytd-commentbox').forEach(setupCommentBox);
      document.querySelectorAll(COMMENT_TEXT_SEL).forEach(processComment);
    }, 250);
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true, subtree: true, characterData: true
  });
  schedule();
})();
