// H3G License — module kiểm tra mã kích hoạt dùng chung cho các tiện ích của Học 3 Giây.
// Bản gốc: G:\game\h3g-license\license.js — chép nguyên file vào tiện ích, KHÔNG sửa trong từng tiện ích.
//
// Dùng trong service worker (background.js, không phải module):
//   importScripts('license.js');
//   H3GLicense.init({ product: 'tai-anh', keyPrefix: 'TAHL' });
//   chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
//     if (H3GLicense.handles(msg)) return H3GLicense.respond(msg, sendResponse);
//     ...
//   });
//   if (!(await H3GLicense.isPro())) { ... chặn tính năng trả phí ... }
//
// Tin nhắn hỗ trợ (trả về { ok, data } hoặc { ok:false, error }):
//   licenseStatus      -> { pro, key, error, product, buyUrl }
//   licenseActivate    { key } -> { pro, key, devices, max }
//   licenseDeactivate  -> { pro:false }
//   openBuy            mở trang mua của sản phẩm

(function () {
  const SERVER = 'https://ytgif-thanh-toan.ytgif-thanh-toan.workers.dev';
  const RECHECK_MS = 24 * 3600 * 1000;        // kiểm tra lại với máy chủ mỗi ngày
  const OFFLINE_GRACE_MS = 14 * 86400 * 1000; // mất mạng vẫn dùng được 14 ngày
  const TYPES = ['licenseStatus', 'licenseActivate', 'licenseDeactivate', 'openBuy'];
  const cfg = { product: null, keyPrefix: null, storageKey: 'lic' };

  function init(opts) {
    Object.assign(cfg, opts);
    if (!cfg.product || !cfg.keyPrefix) throw new Error('H3GLicense.init cần product và keyPrefix');
  }
  const buyUrl = () => SERVER + '/mua/' + cfg.product;

  async function deviceId() {
    let { deviceId } = await chrome.storage.local.get('deviceId');
    if (!deviceId) {
      deviceId = crypto.randomUUID();
      await chrome.storage.local.set({ deviceId });
    }
    return deviceId;
  }

  async function callServer(path, data) {
    const res = await fetch(SERVER + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product: cfg.product, ...data })
    });
    let json = {};
    try { json = await res.json(); } catch (e) {}
    return { status: res.status, json };
  }

  async function getLic() { return (await chrome.storage.local.get(cfg.storageKey))[cfg.storageKey]; }
  async function setLic(lic) { await chrome.storage.local.set({ [cfg.storageKey]: lic }); }

  async function status() {
    const lic = await getLic();
    if (!lic || !lic.key) return { pro: false, product: cfg.product, buyUrl: buyUrl() };
    if (Date.now() - (lic.checkedAt || 0) > RECHECK_MS) {
      try {
        const r = await callServer('/api/verify', { key: lic.key, device: await deviceId() });
        if (r.json.ok) { lic.ok = true; lic.checkedAt = Date.now(); lic.error = ''; }
        else if (r.status === 403 || r.status === 404) { lic.ok = false; lic.error = r.json.error || 'Mã không còn hiệu lực.'; }
        await setLic(lic);
      } catch (e) { /* mất mạng: giữ kết quả cũ */ }
    }
    const pro = !!lic.ok && Date.now() - (lic.checkedAt || 0) < OFFLINE_GRACE_MS;
    return { pro, key: lic.key, error: lic.error || '', product: cfg.product, buyUrl: buyUrl() };
  }

  async function isPro() { return (await status()).pro; }

  async function activate({ key }) {
    key = String(key || '').trim().toUpperCase();
    const re = new RegExp('^' + cfg.keyPrefix + '-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$');
    if (!re.test(key)) throw new Error('Mã kích hoạt có dạng ' + cfg.keyPrefix + '-XXXX-XXXX-XXXX.');
    let r;
    try { r = await callServer('/api/activate', { key, device: await deviceId() }); }
    catch (e) { throw new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.'); }
    if (!r.json.ok) throw new Error(r.json.error || 'Kích hoạt không thành công.');
    await setLic({ key, ok: true, sig: r.json.sig, checkedAt: Date.now(), error: '' });
    return { pro: true, key, devices: r.json.devices, max: r.json.max };
  }

  async function deactivate() {
    const lic = await getLic();
    if (lic && lic.key) {
      try { await callServer('/api/deactivate', { key: lic.key, device: await deviceId() }); } catch (e) {}
    }
    await chrome.storage.local.remove(cfg.storageKey);
    return { pro: false };
  }

  const HANDLERS = {
    licenseStatus: () => status(),
    licenseActivate: (msg) => activate(msg),
    licenseDeactivate: () => deactivate(),
    openBuy: async () => { await chrome.tabs.create({ url: buyUrl() }); return true; }
  };
  const handles = (msg) => !!msg && TYPES.includes(msg.type);
  function respond(msg, sendResponse) {
    HANDLERS[msg.type](msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true; // trả lời bất đồng bộ
  }

  self.H3GLicense = { init, handles, respond, status, isPro, activate, deactivate, buyUrl, SERVER };
})();
